$wnd.com_jensjansson_MyAppWidgetset.runAsyncCallback2('wgb(1596,1,Bae);_.tc=function Rrc(){cdc((!Xcc&&(Xcc=new hdc),Xcc),this.a.d)};N1d(Zh)(2);\n//# sourceURL=com.jensjansson.MyAppWidgetset-2.js\n')
